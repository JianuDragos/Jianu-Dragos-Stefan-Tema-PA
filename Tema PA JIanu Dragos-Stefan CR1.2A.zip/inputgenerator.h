#ifndef INPUTGENERATOR_H
#define INPUTGENERATOR_H

char *random_string(size_t length);
char *similar_string_generator(char *source);
#endif // INPUTGENERATOR_H
